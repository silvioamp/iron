<? include 'topo.php' ?>
  <table cellspacing="0" cellpadding="10" border="0" width="580" style="background-image: url(img/back_servicos.jpg); background-repeat:no-repeat;">
    <tr>
      <td align="center" colspan="2">
       <br><br><br><br><br><br><br><br>
        <? quadro( '550', '200', 'Altera��o de Senha de Acesso', 'C5C5C5', '999999', '707070' , 'borda_servicos' ); ?>
           <br><br><br>
           <center>Sua nova senha estar� dispon�vel em at� 15 minutos.<br><br><br>
           <img src='img/hospedagem/ok.gif' border=0 onclick='window.location="http://www2.litoral.com.br";' style='cursor: hand'>
           </center><br>
        <? fechaquadro(); ?>
      </td>
    </tr>
  </table>
<? include 'rodape.php' ?>